
import { GoogleGenAI, Type } from "@google/genai";
import { MealType, Recipe, WeeklyPlan } from "../types";
import { MAHARASHTRIAN_RECIPES } from "../constants";

// Fix: Initializing GoogleGenAI using the recommended format without fallback empty string
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAITips = async (userProfile: any) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest 3 personalized Maharashtrian fitness tips for ${userProfile.name} who wants to achieve ${userProfile.goal}. Current weight: ${userProfile.weight}kg. Return as a short string.`,
    });
    return response.text || "Keep drinking water and stay active!";
  } catch (err) {
    return "Stay consistent and eat locally sourced food!";
  }
};

export const generateAIWeeklyPlan = async (userProfile: any): Promise<Partial<WeeklyPlan>> => {
  // In a real app, we'd send the recipe list context. 
  // Here we'll simulate AI selecting from our Maharashtrian pool.
  // This is a mockup of the AI response logic.
  const newPlan: Partial<WeeklyPlan> = {};
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
  days.forEach(day => {
    newPlan[day] = {
      [MealType.BREAKFAST]: MAHARASHTRIAN_RECIPES[Math.floor(Math.random() * MAHARASHTRIAN_RECIPES.length)],
      [MealType.LUNCH]: MAHARASHTRIAN_RECIPES[Math.floor(Math.random() * MAHARASHTRIAN_RECIPES.length)],
      [MealType.SNACK]: MAHARASHTRIAN_RECIPES[Math.floor(Math.random() * MAHARASHTRIAN_RECIPES.length)],
      [MealType.DINNER]: MAHARASHTRIAN_RECIPES[Math.floor(Math.random() * MAHARASHTRIAN_RECIPES.length)],
    };
  });

  return newPlan;
};
