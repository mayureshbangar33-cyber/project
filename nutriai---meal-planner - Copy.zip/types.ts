
export enum MealType {
  BREAKFAST = 'Breakfast',
  LUNCH = 'Lunch',
  SNACK = 'Snack',
  DINNER = 'Dinner'
}

export interface Recipe {
  id: string;
  name: string;
  category: MealType;
  image: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  ingredients: string[];
  steps: string[];
  isMaharashtrian: boolean;
}

export interface DayPlan {
  [MealType.BREAKFAST]?: Recipe;
  [MealType.LUNCH]?: Recipe;
  [MealType.SNACK]?: Recipe;
  [MealType.DINNER]?: Recipe;
}

export interface WeeklyPlan {
  [key: string]: DayPlan;
}

export interface UserProfile {
  name: string;
  email: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  weight: number;
  height: number;
  goal: 'Weight Loss' | 'Muscle Gain' | 'Maintenance';
  activityLevel: 'Sedentary' | 'Moderate' | 'Active';
  targetCalories: number;
  isAuthenticated: boolean;
  measurements?: {
    waist?: number;
    hip?: number;
    chest?: number;
  };
}

export interface BodyLog {
  date: string;
  weight: number;
  calories: number;
  waist?: number;
  hip?: number;
  chest?: number;
}

export type View = 'dashboard' | 'planner' | 'recipes' | 'progress' | 'profile' | 'admin';
