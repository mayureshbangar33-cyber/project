
import React from 'react';
import { UserProfile } from '../types';

interface ProfileProps {
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
}

const Profile: React.FC<ProfileProps> = ({ user, setUser }) => {
  const bmiValue = parseFloat((user.weight / ((user.height / 100) ** 2)).toFixed(1));
  
  // Basal Metabolic Rate calculation (Mifflin-St Jeor Equation)
  const calculateBMR = () => {
    const { weight, height, age, gender } = user;
    if (gender === 'Male') {
      return Math.round((10 * weight) + (6.25 * height) - (5 * age) + 5);
    } else {
      return Math.round((10 * weight) + (6.25 * height) - (5 * age) - 161);
    }
  };

  const bmr = calculateBMR();

  const getBMICategory = (val: number) => {
    if (val < 18.5) return { label: 'Underweight', color: 'text-sky-500', bg: 'bg-sky-50' };
    if (val < 25) return { label: 'Healthy', color: 'text-emerald-500', bg: 'bg-emerald-50' };
    if (val < 30) return { label: 'Overweight', color: 'text-orange-500', bg: 'bg-orange-50' };
    return { label: 'Obese', color: 'text-rose-500', bg: 'bg-rose-50' };
  };

  const bmi = getBMICategory(bmiValue);

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-in fade-in duration-700">
      <div className="text-center relative py-10">
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-orange-50 to-transparent -z-10 rounded-t-[3rem]"></div>
        <div className="w-40 h-40 bg-white rounded-[2.5rem] mx-auto relative mb-6 flex items-center justify-center text-6xl shadow-2xl shadow-slate-200/50 border-4 border-white overflow-hidden group">
          <span className="transform transition-transform group-hover:scale-110 duration-500">
            {user.gender === 'Female' ? '👩' : '👨'}
          </span>
          <button className="absolute bottom-2 right-2 bg-orange-500 text-white p-3 rounded-2xl shadow-lg shadow-orange-200 transition-all active:scale-90">
            <span className="text-sm">📸</span>
          </button>
        </div>
        <h2 className="text-4xl font-black text-slate-800 tracking-tighter">{user.name}</h2>
        <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2">{user.email}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Metabolic Breakdown */}
        <div className="bg-white p-10 rounded-[3rem] border border-slate-50 shadow-xl shadow-slate-100/50 flex flex-col justify-center">
          <h3 className="font-black text-2xl text-slate-800 tracking-tight mb-8">Metabolic Profile</h3>
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-orange-50 p-6 rounded-[2rem] text-center">
              <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest mb-1">BMR</p>
              <p className="text-3xl font-black text-orange-600">{bmr}</p>
              <p className="text-[10px] text-orange-400 font-bold">kcal/day (Resting)</p>
            </div>
            <div className="bg-emerald-50 p-6 rounded-[2rem] text-center">
              <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">BMI</p>
              <p className="text-3xl font-black text-emerald-600">{bmiValue}</p>
              <p className={`text-[10px] font-black ${bmi.color}`}>{bmi.label}</p>
            </div>
          </div>
          <div className="mt-8 p-4 bg-slate-50 rounded-2xl text-xs text-slate-500 leading-relaxed italic">
            "Your BMR is the number of calories your body burns at rest. To lose weight, aim for a caloric intake slightly below your BMR adjusted for activity."
          </div>
        </div>

        {/* Core Metrics */}
        <div className="bg-white p-10 rounded-[3rem] border border-slate-50 shadow-xl shadow-slate-100/50">
          <h3 className="font-black text-2xl text-slate-800 tracking-tight mb-8">Basic Info</h3>
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Gender</label>
                <select 
                  value={user.gender}
                  onChange={(e) => setUser({...user, gender: e.target.value as any})}
                  className="w-full bg-slate-50 p-4 rounded-2xl border border-slate-100 font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all appearance-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Age</label>
                <input 
                  type="number" 
                  value={user.age} 
                  onChange={(e) => setUser({...user, age: parseInt(e.target.value)})}
                  className="w-full bg-slate-50 p-4 rounded-2xl border border-slate-100 font-black text-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Weight (kg)</label>
                <input 
                  type="number" 
                  value={user.weight} 
                  onChange={(e) => setUser({...user, weight: parseFloat(e.target.value)})}
                  className="w-full bg-slate-50 p-4 rounded-2xl border border-slate-100 font-black text-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Height (cm)</label>
                <input 
                  type="number" 
                  value={user.height} 
                  onChange={(e) => setUser({...user, height: parseFloat(e.target.value)})}
                  className="w-full bg-slate-50 p-4 rounded-2xl border border-slate-100 font-black text-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Body Measurements Section */}
      <section className="bg-slate-900 p-10 rounded-[3.5rem] shadow-xl text-white overflow-hidden relative">
        <div className="relative z-10">
          <h3 className="font-black text-2xl mb-8 tracking-tight">Body Circumference (cm)</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Waist</label>
              <input 
                type="number" 
                value={user.measurements?.waist || 0}
                onChange={(e) => setUser({...user, measurements: {...(user.measurements || {}), waist: parseFloat(e.target.value)}})}
                className="w-full bg-white/5 p-5 rounded-[1.5rem] border border-white/10 font-black text-2xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Hip</label>
              <input 
                type="number" 
                value={user.measurements?.hip || 0}
                onChange={(e) => setUser({...user, measurements: {...(user.measurements || {}), hip: parseFloat(e.target.value)}})}
                className="w-full bg-white/5 p-5 rounded-[1.5rem] border border-white/10 font-black text-2xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Chest</label>
              <input 
                type="number" 
                value={user.measurements?.chest || 0}
                onChange={(e) => setUser({...user, measurements: {...(user.measurements || {}), chest: parseFloat(e.target.value)}})}
                className="w-full bg-white/5 p-5 rounded-[1.5rem] border border-white/10 font-black text-2xl text-white focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
              />
            </div>
          </div>
          <p className="mt-8 text-xs text-slate-500 max-w-lg">
            "Tracking measurements alongside weight gives a more accurate picture of body recomposition. Muscle is denser than fat, so you might lose centimeters even if the scale doesn't move."
          </p>
        </div>
        <div className="absolute top-[-20%] right-[-10%] w-64 h-64 bg-orange-500/10 rounded-full blur-3xl"></div>
      </section>
    </div>
  );
};

export default Profile;
