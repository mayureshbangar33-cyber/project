
import React, { useState } from 'react';
import { WeeklyPlan, UserProfile, MealType, Recipe } from '../types';
import { DAYS, MAHARASHTRIAN_RECIPES } from '../constants';
import { generateAIWeeklyPlan } from '../services/geminiService';

interface MealPlannerProps {
  weeklyPlan: WeeklyPlan;
  setWeeklyPlan: React.Dispatch<React.SetStateAction<WeeklyPlan>>;
  user: UserProfile;
}

const MealPlanner: React.FC<MealPlannerProps> = ({ weeklyPlan, setWeeklyPlan, user }) => {
  const [loading, setLoading] = useState(false);
  const [selectedDay, setSelectedDay] = useState(DAYS[0]);

  const handleGenerateAI = async () => {
    setLoading(true);
    const newPlan = await generateAIWeeklyPlan(user);
    setWeeklyPlan(newPlan as WeeklyPlan);
    setLoading(false);
  };

  const mealTypes = [MealType.BREAKFAST, MealType.LUNCH, MealType.SNACK, MealType.DINNER];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800">Meal Planner</h2>
          <p className="text-slate-500">Plan your week with delicious Maharashtrian cuisine.</p>
        </div>
        <button 
          onClick={handleGenerateAI}
          disabled={loading}
          className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-2xl shadow-lg shadow-orange-100 transition-all flex items-center space-x-2"
        >
          {loading ? (
            <span className="animate-spin text-xl">🌀</span>
          ) : (
            <span>🤖 Generate AI Weekly Plan</span>
          )}
        </button>
      </div>

      {/* Day Selector */}
      <div className="flex overflow-x-auto pb-2 space-x-2 no-scrollbar">
        {DAYS.map(day => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all flex-shrink-0 ${
              selectedDay === day 
              ? 'bg-slate-900 text-white shadow-xl' 
              : 'bg-white text-slate-500 border border-slate-200'
            }`}
          >
            {day}
          </button>
        ))}
      </div>

      {/* Daily View Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mealTypes.map(type => {
          const meal = weeklyPlan[selectedDay]?.[type];
          return (
            <div key={type} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm relative group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">{type}</span>
                {meal && (
                  <span className="text-xs font-bold text-orange-500 bg-orange-50 px-3 py-1 rounded-full">
                    {meal.calories} kcal
                  </span>
                )}
              </div>

              {meal ? (
                <div className="flex space-x-4">
                  <div className="w-24 h-24 rounded-2xl overflow-hidden flex-shrink-0">
                    <img src={meal.image} alt={meal.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-800 text-lg">{meal.name}</h4>
                    <p className="text-slate-500 text-sm mt-1 mb-3">P: {meal.protein}g • C: {meal.carbs}g • F: {meal.fat}g</p>
                    <button className="text-orange-500 text-xs font-bold hover:underline">Change Meal</button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 border-2 border-dashed border-slate-100 rounded-2xl hover:border-orange-200 transition-colors cursor-pointer">
                  <span className="text-2xl mb-1">➕</span>
                  <p className="text-slate-400 font-bold text-sm">Add {type}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Visual Weekly Grid (Table Desktop) */}
      <div className="hidden lg:block bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden mt-12">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-slate-50 text-left">
              <th className="p-4 text-xs font-bold text-slate-400 uppercase">Day</th>
              {mealTypes.map(m => <th key={m} className="p-4 text-xs font-bold text-slate-400 uppercase">{m}</th>)}
            </tr>
          </thead>
          <tbody>
            {DAYS.map(day => (
              <tr key={day} className="border-t border-slate-50 hover:bg-slate-50/50 transition-colors">
                <td className="p-4 font-bold text-slate-700">{day}</td>
                {mealTypes.map(type => {
                  const meal = weeklyPlan[day]?.[type];
                  return (
                    <td key={type} className="p-4">
                      {meal ? (
                        <div className="text-xs">
                          <p className="font-bold text-slate-800 line-clamp-1">{meal.name}</p>
                          <p className="text-slate-400">{meal.calories} kcal</p>
                        </div>
                      ) : (
                        <span className="text-slate-200">—</span>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MealPlanner;
