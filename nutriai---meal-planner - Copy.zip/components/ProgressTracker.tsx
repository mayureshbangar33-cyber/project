
import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, AreaChart, Area } from 'recharts';
import { BodyLog } from '../types';

interface ProgressTrackerProps {
  logs: BodyLog[];
  onAddLog: (log: BodyLog) => void;
  targetCalories: number;
}

const ProgressTracker: React.FC<ProgressTrackerProps> = ({ logs, onAddLog, targetCalories }) => {
  const [newLog, setNewLog] = useState({
    weight: '',
    calories: '',
    waist: '',
    hip: '',
    chest: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const log: BodyLog = {
      date: new Date().toISOString().split('T')[0],
      weight: parseFloat(newLog.weight),
      calories: parseInt(newLog.calories),
      waist: newLog.waist ? parseFloat(newLog.waist) : undefined,
      hip: newLog.hip ? parseFloat(newLog.hip) : undefined,
      chest: newLog.chest ? parseFloat(newLog.chest) : undefined,
    };
    onAddLog(log);
    setNewLog({ weight: '', calories: '', waist: '', hip: '', chest: '' });
  };

  const formattedWeightData = logs.map(l => ({
    day: l.date.split('-').slice(1).join('/'),
    weight: l.weight,
    waist: l.waist,
    hip: l.hip,
    chest: l.chest
  }));

  const formattedIntakeData = logs.map(l => ({
    day: l.date.split('-').slice(1).join('/'),
    calories: l.calories,
    goal: targetCalories
  }));

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tighter">Biometric Intelligence</h2>
          <p className="text-slate-500 font-medium">Tracking {logs.length} unique data points across 4 vectors.</p>
        </div>
        <div className="flex space-x-3">
          <div className="bg-emerald-50 text-emerald-600 px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-sm">
            Status: Synchronized
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Real-time Log Form */}
        <div className="bg-white p-10 rounded-[3rem] border border-slate-50 shadow-xl shadow-slate-100/50">
          <h3 className="font-black text-2xl text-slate-800 tracking-tight mb-8">Daily Snapshot</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Weight (kg)</label>
                <input 
                  required
                  type="number" 
                  step="0.1"
                  placeholder="75.5"
                  value={newLog.weight}
                  onChange={(e) => setNewLog({...newLog, weight: e.target.value})}
                  className="w-full bg-slate-50 p-4 rounded-2xl border border-slate-100 font-black text-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Calories</label>
                <input 
                  required
                  type="number" 
                  placeholder="2200"
                  value={newLog.calories}
                  onChange={(e) => setNewLog({...newLog, calories: e.target.value})}
                  className="w-full bg-slate-50 p-4 rounded-2xl border border-slate-100 font-black text-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Waist</label>
                <input 
                  type="number" 
                  step="0.5"
                  placeholder="88"
                  value={newLog.waist}
                  onChange={(e) => setNewLog({...newLog, waist: e.target.value})}
                  className="w-full bg-slate-50 p-3 rounded-xl border border-slate-100 font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Hip</label>
                <input 
                  type="number" 
                  step="0.5"
                  placeholder="95"
                  value={newLog.hip}
                  onChange={(e) => setNewLog({...newLog, hip: e.target.value})}
                  className="w-full bg-slate-50 p-3 rounded-xl border border-slate-100 font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Chest</label>
                <input 
                  type="number" 
                  step="0.5"
                  placeholder="102"
                  value={newLog.chest}
                  onChange={(e) => setNewLog({...newLog, chest: e.target.value})}
                  className="w-full bg-slate-50 p-3 rounded-xl border border-slate-100 font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-orange-500 text-white font-black py-5 rounded-[2rem] hover:bg-orange-600 shadow-xl shadow-orange-500/20 transition-all active:scale-95 transform mt-4"
            >
              Update History
            </button>
          </form>
        </div>

        {/* Weight and Measurement Flow Chart */}
        <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-50 shadow-xl shadow-slate-100/50">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h4 className="font-black text-2xl text-slate-800 tracking-tight">Biometric Convergence</h4>
              <p className="text-slate-400 text-sm font-medium">Correlation of mass and volume</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={formattedWeightData}>
                <defs>
                  <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10}} />
                <YAxis hide domain={['dataMin - 5', 'dataMax + 5']} />
                <Tooltip 
                  contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '16px' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="weight" 
                  name="Weight (kg)"
                  stroke="#f97316" 
                  strokeWidth={6} 
                  fillOpacity={1} 
                  fill="url(#colorWeight)"
                />
                <Line 
                  type="monotone" 
                  dataKey="waist" 
                  name="Waist (cm)"
                  stroke="#3b82f6" 
                  strokeWidth={2} 
                  dot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Measurement Breakdown Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <MeasurementSummary icon="📏" label="Waist" current={logs[logs.length-1]?.waist} diff={logs.length > 1 ? logs[logs.length-1].waist! - logs[0].waist! : 0} />
        <MeasurementSummary icon="🍑" label="Hips" current={logs[logs.length-1]?.hip} diff={logs.length > 1 ? logs[logs.length-1].hip! - logs[0].hip! : 0} />
        <MeasurementSummary icon="👕" label="Chest" current={logs[logs.length-1]?.chest} diff={logs.length > 1 ? logs[logs.length-1].chest! - logs[0].chest! : 0} />
      </div>

      {/* Calorie Adherence History */}
      <div className="bg-slate-900 p-10 rounded-[3rem] shadow-xl text-white overflow-hidden relative">
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h4 className="font-black text-2xl tracking-tight">Calorie Adherence History</h4>
              <p className="text-slate-500 text-sm font-medium">Behavioral performance vs metabolic target</p>
            </div>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={formattedIntakeData}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#475569', fontSize: 10}} />
                <YAxis hide />
                <Tooltip 
                  cursor={{fill: 'rgba(255,255,255,0.05)'}}
                  contentStyle={{ borderRadius: '24px', border: 'none', background: '#1e293b', color: '#fff' }}
                />
                <Bar dataKey="calories" name="Consumed" radius={[12, 12, 12, 12]} barSize={45}>
                  {formattedIntakeData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.calories > entry.goal ? '#ef4444' : '#f97316'} 
                    />
                  ))}
                </Bar>
                <Bar dataKey="goal" name="Target" fill="rgba(255,255,255,0.1)" radius={[12, 12, 12, 12]} barSize={45} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="absolute top-[-20%] right-[-10%] w-96 h-96 bg-orange-500/10 rounded-full blur-[100px]"></div>
      </div>
    </div>
  );
};

const MeasurementSummary = ({ icon, label, current, diff }: any) => (
  <div className="bg-white p-8 rounded-[2.5rem] border border-slate-50 shadow-xl shadow-slate-100/30 flex items-center space-x-6">
    <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-2xl shadow-sm">{icon}</div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
      <div className="flex items-baseline space-x-2">
        <span className="text-2xl font-black text-slate-800">{current}cm</span>
        <span className={`text-[10px] font-black ${diff < 0 ? 'text-emerald-500' : diff > 0 ? 'text-rose-500' : 'text-slate-400'}`}>
          {diff > 0 ? '+' : ''}{diff}cm
        </span>
      </div>
    </div>
  </div>
);

export default ProgressTracker;
