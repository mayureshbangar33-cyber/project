
import React, { useState } from 'react';
import { UserProfile } from '../types';

interface AuthProps {
  onLogin: (user: Partial<UserProfile>) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin({
      name: formData.name || (formData.email === 'admin@mahadiet.ai' ? 'Admin' : 'User'),
      email: formData.email,
      isAuthenticated: true
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-900 relative overflow-hidden">
      {/* Decorative background blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-orange-500/10 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[400px] h-[400px] bg-blue-500/10 rounded-full blur-[120px]"></div>

      <div className="w-full max-w-md bg-white rounded-[3rem] shadow-2xl p-8 md:p-12 relative z-10 transform transition-all">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-orange-500 rounded-[2rem] flex items-center justify-center text-white text-4xl font-black mx-auto mb-6 shadow-2xl shadow-orange-500/20 transform hover:rotate-6 transition-transform">
            M
          </div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tighter">MahaDiet AI</h1>
          <p className="text-slate-500 mt-3 font-medium text-sm leading-relaxed">
            {isLogin 
              ? 'Your personalized Maharashtrian nutrition journey continues here.' 
              : 'Join the most advanced local health ecosystem. Sign up for free.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {!isLogin && (
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Your Name</label>
              <input
                required
                type="text"
                placeholder="Manas Patil"
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:ring-2 focus:ring-orange-500 focus:outline-none transition-all font-medium"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
          )}
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
            <input
              required
              type="email"
              placeholder="manas@mahadiet.ai"
              className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:ring-2 focus:ring-orange-500 focus:outline-none transition-all font-medium"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Secure Password</label>
            <input
              required
              type="password"
              placeholder="••••••••"
              className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:ring-2 focus:ring-orange-500 focus:outline-none transition-all font-medium"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
            />
          </div>

          <button
            type="submit"
            className="w-full bg-orange-500 text-white font-black py-5 rounded-2xl hover:bg-orange-600 shadow-xl shadow-orange-500/20 transition-all mt-6 transform active:scale-95"
          >
            {isLogin ? 'Access Dashboard' : 'Create My Account'}
          </button>
        </form>

        <div className="text-center mt-10 text-sm">
          <span className="text-slate-500 font-medium">
            {isLogin ? "New to MahaDiet?" : "Already a member?"}
          </span>
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="ml-2 font-black text-orange-500 hover:text-orange-600 transition-colors"
          >
            {isLogin ? 'Sign Up Now' : 'Sign In'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
