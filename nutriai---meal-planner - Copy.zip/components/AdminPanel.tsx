
import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';

const INITIAL_USERS = [
  { id: 1, name: 'Manas Patil', email: 'manas@mahadiet.ai', weight: 75, goal: 'Weight Loss', status: 'Active', joined: '2023-10-12', isFlagged: false, aiRequests: 45 },
  { id: 2, name: 'Sonal Kulkarni', email: 'sonal@example.com', weight: 62, goal: 'Maintenance', status: 'Active', joined: '2023-11-05', isFlagged: false, aiRequests: 12 },
  { id: 3, name: 'Aditya Ranade', email: 'aditya@example.com', weight: 88, goal: 'Muscle Gain', status: 'Pending', joined: '2023-12-01', isFlagged: true, aiRequests: 89 },
  { id: 4, name: 'Neha Shinde', email: 'neha@example.com', weight: 55, goal: 'Weight Loss', status: 'Inactive', joined: '2023-09-20', isFlagged: false, aiRequests: 5 },
  { id: 5, name: 'Rahul Vaze', email: 'rahul@example.com', weight: 80, goal: 'Muscle Gain', status: 'Active', joined: '2024-01-15', isFlagged: false, aiRequests: 28 },
  { id: 6, name: 'Priya Joshi', email: 'priya@example.com', weight: 58, goal: 'Weight Loss', status: 'Active', joined: '2024-02-01', isFlagged: false, aiRequests: 31 },
];

const ACTIVITY_LOGS = [
  { type: 'MEAL', time: '10:15 AM', description: 'Logged Kanda Poha (250 kcal)', intensity: 'Low' },
  { type: 'AI', time: '11:00 AM', description: 'Asked AI for "post-workout Maharashtrian snack"', intensity: 'Normal' },
  { type: 'BODY', time: '08:00 AM', description: 'Updated body weight to 75.5 kg', intensity: 'Low' },
  { type: 'AI', time: '02:30 PM', description: 'Generated weekly plan with AI', intensity: 'High' },
  { type: 'MEAL', time: '08:45 PM', description: 'Logged Varan Bhaat (380 kcal)', intensity: 'Low' },
];

const INTERACTION_DATA = [
  { name: 'Mon', manual: 400, ai: 240 },
  { name: 'Tue', manual: 300, ai: 139 },
  { name: 'Wed', manual: 200, ai: 980 },
  { name: 'Thu', manual: 278, ai: 390 },
  { name: 'Fri', manual: 189, ai: 480 },
  { name: 'Sat', manual: 239, ai: 380 },
  { name: 'Sun', manual: 349, ai: 430 },
];

const GOAL_COLORS = ['#f97316', '#3b82f6', '#10b981'];

const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState(INITIAL_USERS);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterGoal, setFilterGoal] = useState('All');
  const [selectedUser, setSelectedUser] = useState<any | null>(null);

  const statsData = useMemo(() => {
    const goals = users.reduce((acc: any, user) => {
      acc[user.goal] = (acc[user.goal] || 0) + 1;
      return acc;
    }, {});
    return Object.keys(goals).map(key => ({ name: key, value: goals[key] }));
  }, [users]);

  const filteredAndSortedUsers = useMemo(() => {
    return users.filter(u => 
      (u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (filterGoal === 'All' || u.goal === filterGoal)
    );
  }, [users, searchTerm, filterGoal]);

  const toggleFlag = (id: number) => {
    setUsers(users.map(u => u.id === id ? { ...u, isFlagged: !u.isFlagged } : u));
  };

  const autoFlagReview = () => {
    setUsers(users.map(u => {
      // Flag if user has very high AI requests (potential bot/unusual use) 
      // or if they have flagged keywords (simulated logic)
      if (u.aiRequests > 80) return { ...u, isFlagged: true };
      return u;
    }));
    alert('AI System processed 6 identity nodes. Anomalies flagged.');
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tighter">Command Center</h2>
          <p className="text-slate-500 font-medium">Enterprise monitoring of the nutrition ecosystem.</p>
        </div>
        <div className="flex space-x-3">
           <button 
             onClick={autoFlagReview}
             className="bg-rose-500 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-rose-100 transition-all hover:bg-rose-600 active:scale-95"
           >
             AI Security Scan
           </button>
           <button className="bg-slate-900 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-200 transition-all active:scale-95">
             Sync Nodes
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Interaction Analysis Chart */}
        <div className="lg:col-span-4 bg-white p-10 rounded-[3rem] border border-slate-50 shadow-xl shadow-slate-100/50">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h3 className="font-black text-2xl text-slate-800 tracking-tight">AI vs Manual Interaction</h3>
              <p className="text-slate-400 text-sm font-medium">Weekly behavioral pattern</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={INTERACTION_DATA}>
                <defs>
                  <linearGradient id="colorAi" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorManual" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10}} />
                <Tooltip />
                <Area type="monotone" dataKey="ai" stroke="#f97316" fillOpacity={1} fill="url(#colorAi)" strokeWidth={4} />
                <Area type="monotone" dataKey="manual" stroke="#3b82f6" fillOpacity={1} fill="url(#colorManual)" strokeWidth={4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* User Management List */}
        <div className="lg:col-span-3 bg-white rounded-[3.5rem] border border-slate-50 shadow-2xl shadow-slate-100/50 overflow-hidden">
          <div className="p-10 border-b border-slate-50 space-y-6 bg-slate-50/20">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <h4 className="font-black text-2xl text-slate-800 tracking-tight">Node Directory</h4>
              <div className="relative w-full md:w-72">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
                <input 
                  type="text" 
                  placeholder="Identity Search..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-sm"
                />
              </div>
            </div>
            
            <div className="flex overflow-x-auto no-scrollbar space-x-2">
              {['All', 'Weight Loss', 'Muscle Gain', 'Maintenance'].map(g => (
                <button
                  key={g}
                  onClick={() => setFilterGoal(g)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                    filterGoal === g ? 'bg-orange-500 text-white shadow-lg shadow-orange-200' : 'bg-white text-slate-400 border border-slate-100'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>
          
          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full text-left">
              <tbody className="divide-y divide-slate-50">
                {filteredAndSortedUsers.map(user => (
                  <tr key={user.id} className={`group hover:bg-slate-50/50 transition-all ${user.isFlagged ? 'bg-rose-50/30' : ''}`}>
                    <td className="px-10 py-6">
                      <div className="flex items-center space-x-4">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg transition-all ${
                          user.isFlagged ? 'bg-rose-500 text-white animate-pulse shadow-lg shadow-rose-200' : 'bg-slate-100 text-slate-400 group-hover:bg-orange-100 group-hover:text-orange-500'
                        }`}>
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <p className="font-black text-slate-800 text-sm tracking-tight">{user.name}</p>
                            {user.isFlagged && <span className="bg-rose-500 text-[8px] text-white px-2 py-0.5 rounded-full font-black uppercase tracking-widest">Flagged</span>}
                          </div>
                          <p className="text-xs text-slate-400 font-medium">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-6">
                      <span className="text-[10px] font-black text-slate-600 bg-white border border-slate-100 px-3 py-1.5 rounded-xl uppercase tracking-widest">{user.goal}</span>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">AI REQ</span>
                        <span className="font-black text-slate-800">{user.aiRequests}</span>
                      </div>
                    </td>
                    <td className="px-10 py-6 text-right">
                      <div className="flex items-center justify-end space-x-4">
                        <button 
                          onClick={() => setSelectedUser(user)}
                          className="bg-slate-900 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:bg-black"
                        >
                          Inspect
                        </button>
                        <button 
                          onClick={() => toggleFlag(user.id)}
                          className={`p-2 rounded-xl transition-all ${user.isFlagged ? 'text-rose-500 bg-rose-50' : 'text-slate-300 hover:text-orange-500'}`}
                        >
                          🚩
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Behavioral Metrics Summary */}
        <div className="space-y-8">
          <div className="bg-slate-900 p-8 rounded-[3rem] shadow-xl text-white">
            <h3 className="font-black text-xl mb-6 tracking-tight">Ecosystem Map</h3>
            <div className="h-40 w-full flex items-center justify-center">
              <PieChart width={160} height={160}>
                <Pie
                  data={statsData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={GOAL_COLORS[index % GOAL_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </div>
            <div className="mt-4 space-y-3">
              <div className="flex justify-between items-center text-[10px] font-black tracking-widest text-slate-500">
                <span>SECURITY INCIDENTS</span>
                <span className="text-rose-500">{users.filter(u => u.isFlagged).length} nodes</span>
              </div>
              <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-rose-500 transition-all duration-1000" style={{ width: `${(users.filter(u => u.isFlagged).length / users.length) * 100}%` }}></div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-[3rem] border border-slate-50 shadow-xl shadow-slate-100/50">
            <h3 className="font-black text-xl text-slate-800 mb-6 tracking-tight">AI Utility</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-orange-50 rounded-2xl">
                <span className="text-[10px] font-black text-orange-400">AI PLANS</span>
                <span className="text-orange-600 font-black">2.4k</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-sky-50 rounded-2xl">
                <span className="text-[10px] font-black text-sky-400">RECIPE GEN</span>
                <span className="text-sky-600 font-black">1.8k</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* User Inspection Modal */}
      {selectedUser && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[3rem] overflow-hidden shadow-2xl relative border border-slate-100">
            <button 
              onClick={() => setSelectedUser(null)}
              className="absolute top-6 right-6 w-12 h-12 bg-slate-50 text-slate-400 hover:text-slate-800 rounded-2xl flex items-center justify-center font-black transition-all"
            >
              ✕
            </button>
            <div className="p-10 border-b border-slate-50 bg-slate-50/50">
              <div className="flex items-center space-x-6">
                <div className={`w-20 h-20 rounded-[2.5rem] flex items-center justify-center text-3xl font-black ${selectedUser.isFlagged ? 'bg-rose-500 text-white' : 'bg-slate-900 text-white'}`}>
                  {selectedUser.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-3xl font-black text-slate-800 tracking-tighter">{selectedUser.name}</h3>
                  <p className="text-slate-400 font-medium">Node UID: {selectedUser.id}</p>
                </div>
              </div>
            </div>
            <div className="p-10 max-h-[60vh] overflow-y-auto no-scrollbar">
              <div className="flex items-center justify-between mb-8">
                <h5 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Identity Behavior Stream</h5>
                <span className="text-[10px] font-bold text-emerald-500 bg-emerald-50 px-2 py-1 rounded">Real-time Feed</span>
              </div>
              <div className="space-y-8">
                {ACTIVITY_LOGS.map((log, idx) => (
                  <div key={idx} className="flex space-x-6 items-start relative">
                    <div className="w-px h-full bg-slate-100 absolute left-[23px] top-8 -z-10"></div>
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl flex-shrink-0 shadow-sm border border-slate-50 transition-transform hover:scale-110 ${
                      log.type === 'MEAL' ? 'bg-orange-50 text-orange-600' : 
                      log.type === 'AI' ? 'bg-sky-50 text-sky-600' : 'bg-emerald-50 text-emerald-600'
                    }`}>
                      {log.type === 'MEAL' ? '🍱' : log.type === 'AI' ? '🤖' : '📏'}
                    </div>
                    <div className="flex-1 pb-4">
                      <div className="flex justify-between items-center mb-1">
                        <p className="font-black text-slate-800 text-sm leading-tight">{log.description}</p>
                        <span className="text-[10px] font-bold text-slate-400 whitespace-nowrap">{log.time}</span>
                      </div>
                      <div className="flex items-center space-x-3 mt-2">
                        <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest px-2 py-0.5 border border-slate-100 rounded">Intensity: {log.intensity}</span>
                        {log.intensity === 'High' && <span className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse"></span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-10 p-8 bg-slate-900 rounded-[2.5rem] text-white flex items-center justify-between shadow-2xl shadow-slate-900/20">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">Anomaly Probability</p>
                  <p className="text-3xl font-black">{selectedUser.isFlagged ? 'High (94%)' : 'Low (2%)'}</p>
                </div>
                <button className="bg-orange-500 hover:bg-orange-600 px-6 py-4 rounded-2xl text-xs font-black transition-all shadow-xl shadow-orange-500/20">Action Node</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
