
import React, { useState } from 'react';
import { Recipe, MealType } from '../types';

interface RecipeExplorerProps {
  recipes: Recipe[];
}

const RecipeExplorer: React.FC<RecipeExplorerProps> = ({ recipes }) => {
  const [filter, setFilter] = useState<MealType | 'All'>('All');
  const [search, setSearch] = useState('');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const filteredRecipes = recipes.filter(r => 
    (filter === 'All' || r.category === filter) &&
    r.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="flex-1">
          <h2 className="text-3xl font-bold text-slate-800">Maharashtrian Recipes</h2>
          <p className="text-slate-500">Explore traditional, healthy, and high-protein local dishes.</p>
          <div className="mt-4 relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
            <input 
              type="text" 
              placeholder="Search recipes..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-orange-500 focus:outline-none shadow-sm transition-all"
            />
          </div>
        </div>
      </div>

      <div className="flex space-x-2 overflow-x-auto no-scrollbar pb-2">
        {['All', MealType.BREAKFAST, MealType.LUNCH, MealType.SNACK, MealType.DINNER].map(cat => (
          <button
            key={cat}
            onClick={() => setFilter(cat as any)}
            className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
              filter === cat 
              ? 'bg-orange-500 text-white shadow-lg shadow-orange-100' 
              : 'bg-white text-slate-500 border border-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRecipes.map(recipe => (
          <div 
            key={recipe.id} 
            onClick={() => setSelectedRecipe(recipe)}
            className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-slate-100 cursor-pointer group"
          >
            <div className="h-48 relative overflow-hidden">
              <img 
                src={recipe.image} 
                alt={recipe.name} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
              />
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-orange-600">
                {recipe.calories} kcal
              </div>
            </div>
            <div className="p-5">
              <h4 className="text-lg font-bold text-slate-800 mb-2">{recipe.name}</h4>
              <div className="flex items-center text-slate-400 text-xs font-medium space-x-3">
                <span className="flex items-center">🥩 {recipe.protein}g P</span>
                <span className="flex items-center">🍞 {recipe.carbs}g C</span>
                <span className="flex items-center">🥑 {recipe.fat}g F</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recipe Detail Modal */}
      {selectedRecipe && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in zoom-in duration-300">
          <div className="bg-white w-full max-w-2xl max-h-[90vh] rounded-[2.5rem] overflow-y-auto no-scrollbar shadow-2xl relative">
            <button 
              onClick={() => setSelectedRecipe(null)}
              className="absolute top-6 right-6 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center text-slate-600 hover:text-red-500 z-10"
            >
              ✕
            </button>
            <div className="h-64 relative">
              <img src={selectedRecipe.image} alt={selectedRecipe.name} className="w-full h-full object-cover" />
            </div>
            <div className="p-8">
              <div className="flex items-center space-x-3 mb-4">
                <span className="px-3 py-1 bg-orange-50 text-orange-600 rounded-lg text-xs font-black uppercase tracking-widest">
                  {selectedRecipe.category}
                </span>
                {selectedRecipe.isMaharashtrian && (
                  <span className="px-3 py-1 bg-green-50 text-green-600 rounded-lg text-xs font-black uppercase tracking-widest">
                    Authentic
                  </span>
                )}
              </div>
              <h3 className="text-3xl font-bold text-slate-800 mb-6">{selectedRecipe.name}</h3>
              
              <div className="grid grid-cols-4 gap-4 mb-8">
                <div className="bg-slate-50 p-4 rounded-2xl text-center">
                  <p className="text-xl font-black text-slate-800">{selectedRecipe.calories}</p>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Calories</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl text-center">
                  <p className="text-xl font-black text-slate-800">{selectedRecipe.protein}g</p>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Protein</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl text-center">
                  <p className="text-xl font-black text-slate-800">{selectedRecipe.carbs}g</p>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Carbs</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl text-center">
                  <p className="text-xl font-black text-slate-800">{selectedRecipe.fat}g</p>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Fat</p>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h5 className="font-bold text-slate-800 mb-3 text-lg flex items-center">
                    <span className="mr-2">📝</span> Ingredients
                  </h5>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {selectedRecipe.ingredients.map((ing, idx) => (
                      <li key={idx} className="flex items-center text-slate-600 text-sm">
                        <span className="w-1.5 h-1.5 bg-orange-400 rounded-full mr-3"></span>
                        {ing}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h5 className="font-bold text-slate-800 mb-3 text-lg flex items-center">
                    <span className="mr-2">👩‍🍳</span> Cooking Steps
                  </h5>
                  <div className="space-y-4">
                    {selectedRecipe.steps.map((step, idx) => (
                      <div key={idx} className="flex space-x-4">
                        <span className="w-6 h-6 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-slate-600 text-sm leading-relaxed">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <button className="w-full mt-10 bg-slate-900 text-white font-bold py-4 rounded-2xl hover:bg-black transition-colors">
                Add to My Planner
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RecipeExplorer;
