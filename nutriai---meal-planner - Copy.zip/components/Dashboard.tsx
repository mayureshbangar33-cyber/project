
import React, { useState, useEffect } from 'react';
import { UserProfile, WeeklyPlan, MealType, View, Recipe } from '../types';
import { getAITips } from '../services/geminiService';

interface DashboardProps {
  user: UserProfile;
  weeklyPlan: WeeklyPlan;
  water: number;
  setWater: React.Dispatch<React.SetStateAction<number>>;
  onNavigate: (view: View) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, weeklyPlan, water, setWater, onNavigate }) => {
  const [aiTip, setAiTip] = useState("Analyzing your metabolic data...");
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    const fetchTip = async () => {
      const tip = await getAITips(user);
      setAiTip(tip);
    };
    fetchTip();
    return () => clearInterval(timer);
  }, [user]);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return "Suprabhat";
    if (hour < 17) return "Shubh Dupar";
    return "Shubh Sandhya";
  };

  const today = "Monday"; 
  const todaysMeals = weeklyPlan[today] || {};

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-6 duration-1000">
      {/* Dynamic Hero Section */}
      <section className="relative overflow-hidden rounded-[3rem] bg-slate-900 p-8 md:p-12 text-white">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-orange-500/20 to-transparent"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <span className="bg-orange-500 text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full">AI Active</span>
              <span className="text-slate-400 text-sm font-medium">{currentTime.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-black tracking-tighter leading-none">
              {getGreeting()}, <span className="text-orange-500">{user.name}</span>
            </h2>
            <p className="text-slate-400 font-medium max-w-lg leading-relaxed text-lg italic">
              "{aiTip}"
            </p>
          </div>
          
          <div className="flex bg-white/5 backdrop-blur-xl p-6 rounded-[2.5rem] border border-white/10 items-center space-x-6">
            <div className="text-center">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Local Time</p>
              <p className="text-3xl font-black">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
            </div>
            <div className="w-px h-12 bg-white/10"></div>
            <div className="text-center">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Target</p>
              <p className="text-3xl font-black text-orange-500">{user.targetCalories}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Stats Grid */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <StatWidget 
          icon="🔥" 
          label="Calories" 
          value="1,420" 
          subValue="kcal burnt" 
          progress={65}
          color="orange"
        />
        <StatWidget 
          icon="💧" 
          label="Hydration" 
          value={water.toString()} 
          subValue="glasses" 
          progress={(water/10)*100}
          color="sky"
          action={() => setWater(prev => prev + 1)}
        />
        <StatWidget 
          icon="⚡" 
          label="Protein" 
          value="62" 
          subValue="grams" 
          progress={45}
          color="emerald"
        />
        <StatWidget 
          icon="🎯" 
          label="Goal" 
          value="85%" 
          subValue="adherence" 
          progress={85}
          color="violet"
        />
      </section>

      {/* Today's Meals Section */}
      <section>
        <div className="flex items-center justify-between mb-8 px-2">
          <div>
            <h3 className="text-3xl font-black text-slate-800 tracking-tight">Today's Menu</h3>
            <p className="text-slate-400 font-medium">Authentic Maharashtrian Fuel</p>
          </div>
          <button 
            onClick={() => onNavigate('planner')} 
            className="group flex items-center space-x-2 text-orange-500 font-black uppercase tracking-widest text-xs"
          >
            <span>Full Planner</span>
            <span className="transition-transform group-hover:translate-x-1">→</span>
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.entries(todaysMeals).map(([type, meal]) => {
            const recipe = meal as Recipe;
            return (
              <div key={type} className="group relative bg-white rounded-[3rem] p-4 border border-slate-100 shadow-xl shadow-slate-200/40 transition-all hover:scale-[1.02] hover:shadow-2xl">
                <div className="h-48 rounded-[2.5rem] overflow-hidden mb-6 relative">
                  <img src={recipe.image} alt={recipe.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center text-white">
                    <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 backdrop-blur-md px-3 py-1 rounded-full">{type}</span>
                    <span className="font-black text-lg">{recipe.calories} <span className="text-[10px] font-medium">kcal</span></span>
                  </div>
                </div>
                <div className="px-2 pb-2">
                  <h4 className="text-xl font-black text-slate-800 mb-2 truncate">{recipe.name}</h4>
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    <span>Protein: {recipe.protein}g</span>
                    <div className="w-1 h-1 bg-slate-200 rounded-full"></div>
                    <span>Carbs: {recipe.carbs}g</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Bottom Action Hub */}
      <section className="bg-orange-500 rounded-[3.5rem] p-10 md:p-16 text-white flex flex-col md:flex-row items-center justify-between gap-12 relative overflow-hidden shadow-2xl shadow-orange-500/30">
        <div className="relative z-10 max-w-xl">
          <h3 className="text-4xl md:text-5xl font-black mb-6 tracking-tighter leading-tight">Ready to optimize your <br/>Maharashtrian diet?</h3>
          <p className="text-orange-100 text-lg font-medium leading-relaxed opacity-90">Our AI uses traditional wisdom combined with modern science to craft the perfect meal sequence for your specific body type.</p>
        </div>
        <div className="relative z-10 flex flex-col gap-4 w-full md:w-auto">
          <button 
            onClick={() => onNavigate('planner')}
            className="bg-slate-900 hover:bg-black text-white px-10 py-5 rounded-[2rem] font-black text-lg transition-all shadow-2xl active:scale-95 flex items-center justify-center space-x-3"
          >
            <span>🤖</span>
            <span>Refine Plan with AI</span>
          </button>
          <button className="bg-white/20 hover:bg-white/30 backdrop-blur-md text-white px-10 py-5 rounded-[2rem] font-black text-lg transition-all active:scale-95 flex items-center justify-center space-x-3">
            <span>📝</span>
            <span>Manual Entry</span>
          </button>
        </div>
        
        {/* Decorative blobs */}
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-orange-400 rounded-full blur-3xl opacity-50"></div>
      </section>
    </div>
  );
};

const StatWidget = ({ icon, label, value, subValue, progress, color, action }: any) => {
  const colorMap: any = {
    orange: 'bg-orange-500 text-orange-500',
    sky: 'bg-sky-500 text-sky-500',
    emerald: 'bg-emerald-500 text-emerald-500',
    violet: 'bg-violet-500 text-violet-500'
  };

  return (
    <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/30 flex flex-col items-center text-center relative group">
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mb-4 bg-slate-50 ${colorMap[color].split(' ')[1]}`}>
        {icon}
      </div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <div className="flex items-baseline space-x-1">
        <span className="text-2xl font-black text-slate-800">{value}</span>
        <span className="text-[10px] font-bold text-slate-400">{subValue}</span>
      </div>
      
      <div className="mt-6 w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
        <div 
          className={`h-full ${colorMap[color].split(' ')[0]} transition-all duration-1000`} 
          style={{ width: `${progress}%` }}
        ></div>
      </div>

      {action && (
        <button 
          onClick={action}
          className="absolute -top-2 -right-2 w-8 h-8 bg-slate-900 text-white rounded-xl flex items-center justify-center text-lg shadow-lg opacity-0 group-hover:opacity-100 transition-all hover:scale-110 active:scale-90"
        >
          +
        </button>
      )}
    </div>
  );
};

export default Dashboard;