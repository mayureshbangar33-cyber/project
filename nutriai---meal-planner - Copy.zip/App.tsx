
import React, { useState, useEffect } from 'react';
import { View, UserProfile, WeeklyPlan, BodyLog } from './types';
import { INITIAL_USER, INITIAL_WEEKLY_PLAN, MAHARASHTRIAN_RECIPES } from './constants';
import Dashboard from './components/Dashboard';
import MealPlanner from './components/MealPlanner';
import RecipeExplorer from './components/RecipeExplorer';
import ProgressTracker from './components/ProgressTracker';
import Profile from './components/Profile';
import AdminPanel from './components/AdminPanel';
import Auth from './components/Auth';

const ADMIN_EMAIL = 'admin@mahadiet.ai';

const INITIAL_LOGS: BodyLog[] = [
  { date: '2024-03-01', weight: 76.5, calories: 2100, waist: 90, hip: 96, chest: 103 },
  { date: '2024-03-02', weight: 76.2, calories: 1950, waist: 90, hip: 96, chest: 103 },
  { date: '2024-03-03', weight: 75.8, calories: 2200, waist: 89, hip: 96, chest: 103 },
  { date: '2024-03-04', weight: 75.5, calories: 1800, waist: 88, hip: 95, chest: 102 },
];

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('mahadiet_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });
  
  const [bodyLogs, setBodyLogs] = useState<BodyLog[]>(() => {
    const saved = localStorage.getItem('mahadiet_logs');
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  const [weeklyPlan, setWeeklyPlan] = useState<WeeklyPlan>(INITIAL_WEEKLY_PLAN);
  const [waterGlasses, setWaterGlasses] = useState(4);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if app is running in standalone mode (installed)
    const checkStandalone = window.matchMedia('(display-mode: standalone)').matches 
                           || (window.navigator as any).standalone 
                           || document.referrer.includes('android-app://');
    setIsStandalone(checkStandalone);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  useEffect(() => {
    localStorage.setItem('mahadiet_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('mahadiet_logs', JSON.stringify(bodyLogs));
  }, [bodyLogs]);

  const installApp = async () => {
    if (!deferredPrompt) {
      alert("To install: Use your browser's 'Add to Home Screen' or 'Install' menu option.");
      return;
    }
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setIsStandalone(true);
    }
  };

  const handleLogin = (authData: Partial<UserProfile>) => {
    setUser({ ...user, ...authData, isAuthenticated: true });
  };

  const handleLogout = () => {
    setUser({ ...user, isAuthenticated: false });
    localStorage.removeItem('mahadiet_user');
    setCurrentView('dashboard');
  };

  const addBodyLog = (log: BodyLog) => {
    setBodyLogs(prev => [...prev, log]);
    setUser(prev => ({ ...prev, weight: log.weight }));
  };

  if (!user.isAuthenticated) {
    return <Auth onLogin={handleLogin} />;
  }

  const isAdmin = user.email === ADMIN_EMAIL;

  const NavItem = ({ view, label, icon }: { view: View, label: string, icon: string }) => (
    <button
      onClick={() => { setCurrentView(view); setIsSidebarOpen(false); }}
      className={`flex items-center space-x-4 w-full px-5 py-4 rounded-2xl transition-all duration-300 relative group ${
        currentView === view 
        ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/30' 
        : 'text-slate-500 hover:bg-slate-100'
      }`}
    >
      <span className="text-xl">{icon}</span>
      <span className="font-bold tracking-tight">{label}</span>
    </button>
  );

  return (
    <div className="h-screen bg-slate-50 flex flex-col md:flex-row overflow-hidden font-['Plus_Jakarta_Sans']">
      {/* Mobile Top Navigation */}
      <header className="md:hidden flex items-center justify-between p-5 bg-white border-b border-slate-100 z-50">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center text-white font-black text-xs">M</div>
          <span className="font-black text-slate-800 tracking-tight">MahaDiet AI</span>
        </div>
        <div className="flex items-center space-x-2">
          {!isStandalone && (
            <button onClick={installApp} className="bg-orange-50 text-orange-600 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest">
              Install
            </button>
          )}
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
            className="w-10 h-10 flex items-center justify-center bg-slate-50 rounded-xl text-slate-600 active:scale-95 transition-all"
          >
            {isSidebarOpen ? '✕' : '☰'}
          </button>
        </div>
      </header>

      {/* Sidebar Navigation */}
      <aside className={`
        fixed inset-0 z-[60] bg-white md:relative md:flex md:flex-col w-full md:w-80 h-full border-r border-slate-100 p-8 space-y-8
        transform transition-all duration-500 ease-in-out
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="hidden md:flex items-center space-x-4 mb-4">
          <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center text-white text-2xl font-black shadow-lg shadow-orange-500/20">M</div>
          <div>
            <h1 className="text-xl font-black text-slate-800 tracking-tighter leading-none">MahaDiet</h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Health Intelligence</p>
          </div>
        </div>

        <nav className="flex-1 space-y-2 overflow-y-auto no-scrollbar">
          <NavItem view="dashboard" label="Home Feed" icon="🏠" />
          <NavItem view="planner" label="Meal Planner" icon="📅" />
          <NavItem view="recipes" label="Recipe Vault" icon="🥗" />
          <NavItem view="progress" label="Bio Analytics" icon="📊" />
          <NavItem view="profile" label="User Identity" icon="👤" />
          {isAdmin && <NavItem view="admin" label="Command Center" icon="🛡️" />}
        </nav>

        <div className="space-y-4 pt-6 border-t border-slate-100">
          {!isStandalone && (
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-[2rem] p-6 text-white shadow-xl shadow-orange-500/20">
              <p className="text-xs font-black uppercase tracking-widest mb-2 opacity-80">Full Experience</p>
              <p className="font-bold text-sm mb-4 leading-snug">Add MahaDiet to your home screen for offline access.</p>
              <button 
                onClick={installApp}
                className="w-full py-3 bg-white text-orange-600 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg active:scale-95 transition-all"
              >
                Install App
              </button>
            </div>
          )}
          
          <button 
            onClick={handleLogout}
            className="w-full py-4 text-slate-400 hover:text-rose-500 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-colors flex items-center justify-center space-x-2"
          >
            <span>🚪 Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main View Area */}
      <main className="flex-1 h-full overflow-y-auto p-4 md:p-12 no-scrollbar scroll-smooth">
        <div className="max-w-6xl mx-auto pb-24 md:pb-6">
          {currentView === 'dashboard' && (
            <Dashboard 
              user={user} 
              weeklyPlan={weeklyPlan} 
              water={waterGlasses} 
              setWater={setWaterGlasses}
              onNavigate={setCurrentView}
            />
          )}
          {currentView === 'planner' && (
            <MealPlanner 
              weeklyPlan={weeklyPlan} 
              setWeeklyPlan={setWeeklyPlan} 
              user={user}
            />
          )}
          {currentView === 'recipes' && (
            <RecipeExplorer recipes={MAHARASHTRIAN_RECIPES} />
          )}
          {currentView === 'progress' && (
            <ProgressTracker logs={bodyLogs} onAddLog={addBodyLog} targetCalories={user.targetCalories} />
          )}
          {currentView === 'profile' && (
            <Profile user={user} setUser={setUser} />
          )}
          {currentView === 'admin' && isAdmin && (
            <AdminPanel />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
