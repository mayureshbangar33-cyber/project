
import { MealType, Recipe, UserProfile, WeeklyPlan } from './types';

export const MAHARASHTRIAN_RECIPES: Recipe[] = [
  {
    id: '1',
    name: 'Kanda Poha',
    category: MealType.BREAKFAST,
    image: 'https://images.unsplash.com/photo-1626132646529-500337552978?q=80&w=800&auto=format&fit=crop',
    calories: 250,
    protein: 5,
    carbs: 45,
    fat: 6,
    ingredients: ['Flattened rice', 'Onion', 'Peanuts', 'Turmeric', 'Green chilies', 'Curry leaves'],
    steps: ['Wash poha', 'Sauté onions and peanuts', 'Add spices', 'Mix and steam'],
    isMaharashtrian: true
  },
  {
    id: '2',
    name: 'Spicy Misal Pav',
    category: MealType.BREAKFAST,
    image: 'https://images.unsplash.com/photo-1635363638580-c2809d049eee?q=80&w=800&auto=format&fit=crop',
    calories: 480,
    protein: 16,
    carbs: 62,
    fat: 20,
    ingredients: ['Sprouted moth beans', 'Farsan', 'Pav', 'Kala Masala', 'Onion', 'Lemon'],
    steps: ['Cook rassa (spicy gravy)', 'Assemble sprouts and farsan', 'Serve with buttered pav'],
    isMaharashtrian: true
  },
  {
    id: '3',
    name: 'Pithla Bhakri',
    category: MealType.LUNCH,
    image: 'https://images.unsplash.com/photo-1605333396915-47ed6b68a00e?q=80&w=800&auto=format&fit=crop',
    calories: 420,
    protein: 14,
    carbs: 68,
    fat: 12,
    ingredients: ['Gram flour', 'Jowar flour', 'Green chili paste', 'Garlic', 'Mustard seeds'],
    steps: ['Make bhakri on tawa', 'Cook thick besan pithla', 'Serve with raw onion'],
    isMaharashtrian: true
  },
  {
    id: '6',
    name: 'Bharli Vangi',
    category: MealType.DINNER,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=800&auto=format&fit=crop',
    calories: 310,
    protein: 7,
    carbs: 18,
    fat: 24,
    ingredients: ['Eggplants', 'Peanut powder', 'Gods masala', 'Garlic', 'Jaggery'],
    steps: ['Stuff eggplants with spice paste', 'Pan fry until tender', 'Slow simmer'],
    isMaharashtrian: true
  },
  {
    id: '7',
    name: 'Varan Bhaat with Ghee',
    category: MealType.DINNER,
    image: 'https://images.unsplash.com/photo-1596797038530-2c39fa81b487?q=80&w=800&auto=format&fit=crop',
    calories: 380,
    protein: 11,
    carbs: 58,
    fat: 10,
    ingredients: ['Toor dal', 'Basmati rice', 'Cow Ghee', 'Turmeric', 'Cumin'],
    steps: ['Pressure cook dal until mashy', 'Prepare steamed rice', 'Add dollop of ghee'],
    isMaharashtrian: true
  },
  {
    id: '8',
    name: 'Sabudana Khichdi',
    category: MealType.SNACK,
    image: 'https://images.unsplash.com/photo-1601050633647-8f8f1f35d236?q=80&w=800&auto=format&fit=crop',
    calories: 340,
    protein: 3,
    carbs: 72,
    fat: 8,
    ingredients: ['Sago pearls', 'Roasted Peanuts', 'Green chilies', 'Potato', 'Cumin'],
    steps: ['Soak sabudana overnight', 'Mix with crushed peanuts', 'Sauté with cumin and chilies'],
    isMaharashtrian: true
  }
];

export const INITIAL_USER: UserProfile = {
  name: 'Manas',
  email: 'manas@mahadiet.ai',
  age: 26,
  gender: 'Male',
  weight: 75,
  height: 178,
  goal: 'Weight Loss',
  activityLevel: 'Moderate',
  targetCalories: 2200,
  isAuthenticated: false,
  measurements: {
    waist: 88,
    hip: 95,
    chest: 102
  }
};

export const INITIAL_WEEKLY_PLAN: WeeklyPlan = {
  'Monday': {
    [MealType.BREAKFAST]: MAHARASHTRIAN_RECIPES[0],
    [MealType.LUNCH]: MAHARASHTRIAN_RECIPES[2],
    [MealType.SNACK]: MAHARASHTRIAN_RECIPES[5],
    [MealType.DINNER]: MAHARASHTRIAN_RECIPES[3]
  }
};

export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
